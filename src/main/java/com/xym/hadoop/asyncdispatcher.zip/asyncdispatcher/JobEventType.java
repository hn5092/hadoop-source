package com.xym.hadoop.asyncdispatcher;

public enum JobEventType {
	JOB_KILL, JOB_PREPARE,JOB_INIT, JOB_START, JOB_SETUP_COMPLETED, JOB_COMPLETED,INTERNAL_ERROR
}
