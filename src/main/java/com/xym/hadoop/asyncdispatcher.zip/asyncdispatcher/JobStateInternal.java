package com.xym.hadoop.asyncdispatcher;
  public enum JobStateInternal { //作业内部状态  
	CREATE,
    NEW,  
    SETUP,  
    INITED,  
    RUNNING,  
    SUCCEEDED,  
    KILLED,  
  }  
