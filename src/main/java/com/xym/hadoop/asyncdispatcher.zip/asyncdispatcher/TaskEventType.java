package com.xym.hadoop.asyncdispatcher;

public enum TaskEventType {
T_KILL,
T_SCHEDULE
}
