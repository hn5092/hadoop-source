package com.xym.hadoop.asyncdispatcher;

import org.apache.hadoop.yarn.state.SingleArcTransition;


